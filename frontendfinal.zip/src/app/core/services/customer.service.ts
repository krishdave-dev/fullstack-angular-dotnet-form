import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { ApiResponse, CustomerQueryDto, CustomerResponseDto, PagedResponse } from '../../shared/models/customer.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private http = inject(HttpClient);
  private apiUrl = 'http://localhost:5137/api/customers';
  
  //read - get all with pagination
  getAll(query: CustomerQueryDto): Observable<ApiResponse<PagedResponse<CustomerResponseDto>>>{
    let params = new HttpParams()
    .set('pageNumber', query.pageNumber.toString())
    .set('pageSize', query.pageSize.toString())
    .set('sortDescending', query.sortDescending.toString());

    if(query.search) params = params.set('search', query.search);
    if(query.sortBy) params = params.set('sortBy', query.sortBy);

    return this.http.get<ApiResponse<PagedResponse<CustomerResponseDto>>>(this.apiUrl, {params});
  }

  //read - get by id
  getById(id: number): Observable<ApiResponse<CustomerResponseDto>>{
    return this.http.get<ApiResponse<CustomerResponseDto>>(`${this.apiUrl}/${id}`);
  }

  //create
  create(customer: any): Observable<ApiResponse<CustomerResponseDto>>{
    return this.http.post<ApiResponse<CustomerResponseDto>>(this.apiUrl, customer);
  }

  //update
  update(id: number, customer: any): Observable<ApiResponse<CustomerResponseDto>>{
    return this.http.put<ApiResponse<CustomerResponseDto>>(`${this.apiUrl}/${id}`, customer);
  }

  //delete
  delete(id: number): Observable<ApiResponse<any>>{
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/${id}`);
  }

}
