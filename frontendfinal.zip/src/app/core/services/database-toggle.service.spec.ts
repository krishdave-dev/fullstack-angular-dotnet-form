import { TestBed } from '@angular/core/testing';

import { DatabaseToggleService } from './database-toggle.service';

describe('DatabaseToggleService', () => {
  let service: DatabaseToggleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatabaseToggleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
