import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DatabaseToggleService {

  private currentDbModeSource = new BehaviorSubject<string>('EFCore');

  currentDbMode$: Observable<string> = this.currentDbModeSource.asObservable();

  setDatabaseMode(mode: 'ADO' | 'EFCore'): void {
    this.currentDbModeSource.next(mode);
  }

  getDatabaseMode(): string{
    return this.currentDbModeSource.value;
  }
}
