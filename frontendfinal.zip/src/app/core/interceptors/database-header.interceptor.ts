import { HttpInterceptorFn } from '@angular/common/http';
import { DatabaseToggleService } from '../services/database-toggle.service';
import { inject } from '@angular/core';

export const databaseHeaderInterceptor: HttpInterceptorFn = (req, next) => {
  const dbToggleService = inject(DatabaseToggleService);
  const selectedMode = dbToggleService.getDatabaseMode();

  const modifiedRequest = req.clone({
    setHeaders:{
      'x-data-access': selectedMode
    }
  });
  
  return next(modifiedRequest);
};
