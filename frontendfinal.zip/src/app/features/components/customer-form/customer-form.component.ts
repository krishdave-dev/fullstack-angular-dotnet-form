import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CustomerResponseDto } from '../../../shared/models/customer.model';
import { CustomerService } from '../../../core/services/customer.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-customer-form',
  standalone: true,
  imports: [CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule],
  templateUrl: './customer-form.component.html',
  styleUrl: './customer-form.component.css'
})
export class CustomerFormComponent implements OnChanges {
  private fb = inject(FormBuilder);
  private customerService = inject(CustomerService);
  private toastr = inject(ToastrService)
  // Read data sent down from parent when edit button clicked
  @Input() customerData: CustomerResponseDto | null = null;

  // Emit event outcomes upwards to notify parent when table needs refreshing
  @Output() onSaveSuccess = new EventEmitter<string>();
  @Output() onCancel = new EventEmitter<void>();

  customerForm!: FormGroup;
  isEditMode = false;
  isSubmitting = false;
  maxDate: string; // Used to block selection of future birth dates

  constructor() {
    this.maxDate = new Date().toISOString().split('T')[0]; // Current date as YYYY-MM-DD
    this.initForm();
  }

  initForm(): void {
    this.customerForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      dateOfBirth: ['', [Validators.required, this.futureDateValidator]],
      city: ['', [Validators.required]]
    });
  }

  futureDateValidator(control: any){
    if(!control.value) return null;

    const selectedDate = new Date(control.value);
    const today = new Date();

    today.setHours(0,0,0,0);

    return selectedDate > today ? { isFutureDate: true} : null;
  }

  ngOnChanges(changes: SimpleChanges): void {
    // If parent pushes a customer object into 'customerData', switch to Edit mode
    if (changes['customerData'] && this.customerData) {
      this.isEditMode = true;
      
      // SQL/C# DateTime stamps include times, so strip down to format 'YYYY-MM-DD' for input fields
      const formattedDob = this.customerData.dateOfBirth.split('T')[0];

      this.customerForm.patchValue({
        firstName: this.customerData.firstName,
        lastName: this.customerData.lastName,
        email: this.customerData.email,
        dateOfBirth: formattedDob,
        city: this.customerData.city
      });
    } else if (changes['customerData'] && !this.customerData) {
      this.resetFormState();
    }
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.customerForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  onSubmit(): void {
    if (this.customerForm.invalid) {
      this.customerForm.markAllAsTouched(); // Instantly displays validation rules
      this.toastr.warning('Please correct the validation error in tha form.')
      return;
    }

    this.isSubmitting = true;
    const formData = this.customerForm.value;

    if (this.isEditMode && this.customerData) {
      // Execute UPDATE action flow
      this.customerService.update(this.customerData.id, formData).subscribe({
        next: (response) => {
          if (response.success) {
            this.onSaveSuccess.emit('Customer record updated successfully.');
          }else{
            this.toastr.error(response.message || 'Failed to update customer record.', 'Update Error')
          }
          this.isSubmitting = false;
        },
        error: () => {this.isSubmitting = false
          this.toastr.error('An unexpected server error occured during update', 'System Failure')
        }
      });
    } else {
      // Execute CREATE action flow
      this.customerService.create(formData).subscribe({
        next: (response) => {
          if (response.success) {
            this.onSaveSuccess.emit('New customer record added successfully.');
          }else{
            this.toastr.error(response.message || 'Failed to create new customer profile.', 'Creation Error'); 
          }
          this.isSubmitting = false;
        },
        error: () => {
        this.isSubmitting = false;
        this.toastr.error('An unexpected server error occurred during creation.', 'System Failure');
      }
      });
    }
  }

  onCancelEdit(): void {
    this.resetFormState();
    this.onCancel.emit();
  }

  resetFormState(): void {
    this.isEditMode = false;
    this.isSubmitting = false;
    this.customerForm.reset();
  }
}