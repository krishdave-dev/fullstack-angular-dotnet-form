import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { CustomerResponseDto } from '../../../shared/models/customer.model';
import { CustomerService } from '../../../core/services/customer.service';
import { CustomerCardComponent } from '../../../shared/components/customer-card/customer-card.component';

@Component({
  selector: 'app-customer-card-page',
  standalone: true,
  imports: [CustomerCardComponent, RouterModule],
  templateUrl: './customer-card-page.component.html',
  styleUrl: './customer-card-page.component.css'
})
export class CustomerCardPageComponent implements OnInit{
  private route = inject(ActivatedRoute);
  private customerService = inject(CustomerService);

  customerData: CustomerResponseDto | null = null;

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id){
      this.customerService.getById(id).subscribe({
        next: (res) =>{
          if(res.success && res.data){
            this.customerData = res.data;
          }
        }
      })
    }
  }

}
