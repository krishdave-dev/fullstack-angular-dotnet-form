import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerCardPageComponent } from './customer-card-page.component';

describe('CustomerCardPageComponent', () => {
  let component: CustomerCardPageComponent;
  let fixture: ComponentFixture<CustomerCardPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomerCardPageComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustomerCardPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
