import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { CustomerQueryDto, CustomerResponseDto, PagedResponse } from '../../../shared/models/customer.model';
import { ConfirmDialogComponent } from '../../../shared/components/confirm-dialog/confirm-dialog.component';
import { RouterModule } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-customer-list',
  standalone: true,
  imports: [
    RouterModule,
    CommonModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatDialogModule,
    MatProgressSpinnerModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './customer-list.component.html',
  styleUrl: './customer-list.component.css'
})
export class CustomerListComponent implements OnChanges {
  private dialog = inject(MatDialog);
  private toastr = inject(ToastrService);

  // Structural @Inputs coming downwards from the parent orchestrator 
  @Input() pagedData?: PagedResponse<CustomerResponseDto>;
  @Input() isLoading = false;

  // Intercept events and emit data changes upwards to the orchestrator
  @Output() onQueryChange = new EventEmitter<CustomerQueryDto>();
  @Output() onEditRequested = new EventEmitter<CustomerResponseDto>();
  @Output() onDeleteRequested = new EventEmitter<number>();

  // Component states and config arrays
  displayedColumns: string[] = ['id', 'name', 'email', 'dob', 'city', 'actions'];
  dataSource: CustomerResponseDto[] = [];
  searchTerm: string = '';

  // Setup a RxJS subject stream to handle real-time search field debouncing
  private searchSubject = new Subject<string>();

  // Default parameters tracking our grid layout
  private currentQueryState: CustomerQueryDto = {
    pageNumber: 1,
    pageSize: 10,
    search: '',
    sortBy: 'Id',
    sortDescending: false
  };

  constructor() {
    // Debounce processing: prevents API hammering on every single keyboard letter stroke
    this.searchSubject.pipe(
      debounceTime(400),
      distinctUntilChanged()
    ).subscribe(text => {
      this.currentQueryState.search = text;
      this.currentQueryState.pageNumber = 1; // Reset to page 1 during keyword changes
      this.onQueryChange.emit({ ...this.currentQueryState });
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Keep data sources perfectly in sync with incoming parent property variables
    if (changes['pagedData'] && this.pagedData) {
      this.dataSource = this.pagedData.data;
      this.currentQueryState.pageNumber = this.pagedData.pageNumber;
      this.currentQueryState.pageSize = this.pagedData.pageSize;
    }
  }

  onSearchChanged(text: string): void {
    this.searchSubject.next(text);
  }

  onPageChanged(event: PageEvent): void {
    this.currentQueryState.pageNumber = event.pageIndex + 1; // Material index is 0-based
    this.currentQueryState.pageSize = event.pageSize;
    this.onQueryChange.emit({ ...this.currentQueryState });
  }

  onEdit(customer: CustomerResponseDto): void {
    this.onEditRequested.emit(customer);
  }

  onDelete(customer: CustomerResponseDto): void {
    // Open the Material Dialog Confirmation popup built earlier
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      disableClose: true,
      data: {
        title: 'Delete Customer Profile?',
        message: `Are you sure you want to completely delete the customer profile record for "${customer.firstName} ${customer.lastName}"? This process cannot be undone.`
      }
    });

    dialogRef.afterClosed().subscribe(confirmed => {
      if (confirmed) {
                this.toastr.info('Processing deletion request...', 'Please Wait');

        this.onDeleteRequested.emit(customer.id);
      }
    });
  }
}
