import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { CustomerFormComponent } from '../components/customer-form/customer-form.component';
import { CustomerListComponent } from '../components/customer-list/customer-list.component';
import { CustomerService } from '../../core/services/customer.service';
import { DatabaseToggleService } from '../../core/services/database-toggle.service';
import { CustomerQueryDto, CustomerResponseDto, PagedResponse } from '../../shared/models/customer.model';

@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    CustomerListComponent,
    CustomerFormComponent
  ],
  templateUrl: './customers.component.html',
  styleUrl: './customers.component.css'
})
export class CustomersComponent implements OnInit, OnDestroy {
  private customerService = inject(CustomerService);
  private dbToggleService = inject(DatabaseToggleService);
  private toastr = inject(ToastrService);
  private dbSub!: Subscription;

  //data binding variables
  pagedData?: PagedResponse<CustomerResponseDto>;
  selectedCustomer: CustomerResponseDto | null = null;
  isLoading = false;

  private currentQuery: CustomerQueryDto = {
    pageNumber: 1,
    pageSize: 10,
    search: '',
    sortBy: 'Id',
    sortDescending: false
  };
  //listen to database toggle
  //automatic reload to last grid
  ngOnInit(): void {
    this.dbSub = this.dbToggleService.currentDbMode$.subscribe(()=>{
      this.fetchCustomers(this.currentQuery)
    });
  }

  fetchCustomers(query: CustomerQueryDto): void{
    this.isLoading = true;
    this.currentQuery = query;

    this.customerService.getAll(query).subscribe({
      next: (response) =>{
        if(response.success && response.data){
          this.pagedData = response.data;
        }else{
          this.toastr.error(response.message || 'Failed to load records.');
        }
        this.isLoading = false;
      },
      error: (err) =>{
        this.isLoading = false;
      }
    });
  }

  onEditCustomer(customer: CustomerResponseDto): void{
    this.selectedCustomer = customer;
    this.toastr.info(`Editing details for ${customer.firstName}`);
  }

  onDeleteCustomer(id: number): void {
    this.customerService.delete(id).subscribe({
      next: (response) => {
        if (response.success) {
          this.toastr.success('Customer profile removed successfully.');
          
          // Clear form selection if we deleted the profile currently being edited
          if (this.selectedCustomer?.id === id) {
            this.clearSelection();
          }
          
          // Refresh the grid viewport state
          this.fetchCustomers(this.currentQuery);
        } else {
          this.toastr.error(response.message || 'Unable to delete customer.');
        }
      }
    });
  }

  onFormSaveSuccess(message: string): void {
    this.toastr.success(message);
    this.clearSelection();
    this.fetchCustomers(this.currentQuery); // Re-render grid data structures
  }

  clearSelection(): void {
    this.selectedCustomer = null;
  }

  ngOnDestroy(): void {
    if (this.dbSub) this.dbSub.unsubscribe();
  }
}
