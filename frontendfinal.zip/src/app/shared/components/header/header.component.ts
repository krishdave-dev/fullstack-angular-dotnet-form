import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { DatabaseToggleService } from '../../../core/services/database-toggle.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, MatSlideToggleModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  private dbService = inject(DatabaseToggleService);
  private sub! : Subscription;

  currentMode: string = 'EFCore';

  ngOnInit(): void{
    this.sub = this.dbService.currentDbMode$.subscribe(mode=>{
      this.currentMode = mode;
    });
  }

  onToggleChange(isEFCore: boolean): void{
    const targetMode = isEFCore ? 'EFCore' : 'ADO';
    this.dbService.setDatabaseMode(targetMode);
  }

  ngOnDestroy(): void{
    if(this.sub) this.sub.unsubscribe();
  }
}
