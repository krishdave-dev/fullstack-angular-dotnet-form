import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { CustomerResponseDto } from '../../models/customer.model';
@Component({
  selector: 'app-customer-card',
  standalone: true,
  imports: [MatCardModule, CommonModule],
  templateUrl: './customer-card.component.html',
  styleUrl: './customer-card.component.css'
})
export class CustomerCardComponent {
  @Input() customer: CustomerResponseDto | null = null;
}
