import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'customers',
    pathMatch: 'full'
  },
  {
    path: 'customers',
    loadComponent: () => import('./features/customers/customers.component').then(m => m.CustomersComponent)
  },
  {
    path: 'customers/details/:id',
    // Clicking a row ID takes the user here to look at the isolated Card Component
    loadComponent: () => import('./features/components/customer-card-page/customer-card-page.component').then(m => m.CustomerCardPageComponent)
  },
  {
    path: '**',
    redirectTo: 'customers'
  }
];
