using Backend.Data;
using Backend.Exceptions;
using Backend.Interfaces;
using Backend.Models.DTOs;
using Backend.Validations;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Runtime.Intrinsics.Wasm;

namespace Backend.Repositories.ADO;

public class CustomerAdoRepository
    : ICustomerRepository
{
    private readonly DbConnectionFactory
        _connectionFactory;

    public CustomerAdoRepository(DbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<PagedResponse<CustomerResponseDto>>
        GetAllAsync(CustomerQueryDto query)
    {
        try
        {
            var customers = new List<CustomerResponseDto>();
            int totalRecordsCount = 0; // Tracks our total matching rows count
            using var con = _connectionFactory.CreateConnection();

            using var cmd = new SqlCommand("sp_Customers_GetAll_Krish", con);

            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@PageNumber", query.PageNumber);

            cmd.Parameters.AddWithValue("@PageSize", query.PageSize);

            cmd.Parameters.AddWithValue("@Search",(object?)query.Search?? DBNull.Value);

            await con.OpenAsync();

            using var reader =await cmd.ExecuteReaderAsync();
            bool isFirstRow = true;
            while (await reader.ReadAsync())
            {
                if (isFirstRow)
                    {
                         //I optimized this by utilizing SQL Server's COUNT(*) OVER() window function directly inside our stored procedure. 
                         // This retrieves the total matching records count and our paginated layout block in a single database trip, 
                         // updating the frontend without performance drops.
                        totalRecordsCount = Convert.ToInt32(reader["TotalRecords"]);
                        isFirstRow = false;
                    }
                customers.Add(new CustomerResponseDto
                    {
                        Id = reader.GetInt32("Id"),

                        FirstName =reader.GetString("FirstName"),

                        LastName =reader.GetString("LastName"), 

                        Email =reader.GetString("Email"),

                        DateOfBirth =reader.GetDateTime("DateOfBirth"),

                        City =reader.GetString("City")
                    });
            }
            Console.WriteLine("total rows in db: ",totalRecordsCount);

            return new PagedResponse
                <CustomerResponseDto>
            {
                Data = customers,
                PageNumber =query.PageNumber,
                PageSize = query.PageSize,
                TotalRecords =totalRecordsCount
            };
        }
        catch (SqlException ex)
        {
            throw new Exception("Database Error Occured.", ex);
        }

    }

    public async Task<CustomerResponseDto?>
    GetByIdAsync(int id)
    {
        try
        {
            using var con =
                _connectionFactory.CreateConnection();

            using var cmd =
                new SqlCommand(
                    "sp_Customers_GetById_Krish",
                    con);

            cmd.CommandType =
                CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue(
                "@Id",
                id);

            await con.OpenAsync();

            using var reader =
                await cmd.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return new CustomerResponseDto
                {
                    Id = reader.GetInt32("Id"),
                    FirstName = reader.GetString("FirstName"),
                    LastName = reader.GetString("LastName"),
                    Email = reader.GetString("Email"),
                    DateOfBirth =
                        reader.GetDateTime(
                            "DateOfBirth"),
                    City =
                        reader.GetString(
                            "City")
                };
            }

            throw new NotFoundException(
                "Customer not found");
        }
        catch (SqlException ex)
        {
            throw new Exception(
                "Database error occurred.",
                ex);
        }
    }
    public async Task<CustomerResponseDto>
    CreateAsync(CreateCustomerDto dto)
    {
        try
        {
            CustomerValidator.Validate(dto);

            using var con =
                _connectionFactory.CreateConnection();
            await con.OpenAsync();
            // 1. INLINE ADO.NET UNIQUE EMAIL CHECK
            string checkSql = "SELECT COUNT(1) FROM Customers_Krish WHERE LOWER(Email) = LOWER(@Email) AND IsDeleted = 0";
            using (var checkCmd = new SqlCommand(checkSql, con))
            {
                checkCmd.Parameters.AddWithValue("@Email", dto.Email);
                int count = Convert.ToInt32(await checkCmd.ExecuteScalarAsync());
                
                if (count > 0)
                {
                    throw new ValidationException(new List<string> { "This email address is already registered to another customer." });
                }
            }

            using var cmd =
                new SqlCommand(
                    "sp_Customers_Insert_Krish",
                    con);

            cmd.CommandType =
                CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue(
                "@FirstName",
                dto.FirstName);

            cmd.Parameters.AddWithValue(
                "@LastName",
                dto.LastName);

            cmd.Parameters.AddWithValue(
                "@Email",
                dto.Email);

            cmd.Parameters.AddWithValue(
                "@DateOfBirth",
                dto.DateOfBirth);

            cmd.Parameters.AddWithValue(
                "@City",
                dto.City);

            

            var id =
                Convert.ToInt32(
                    await cmd.ExecuteScalarAsync());

            return
                (await GetByIdAsync(id))!;
        }
        catch (SqlException ex)
        {
            throw new Exception(
                "Failed to create customer.",
                ex);
        }
    }
    public async Task<CustomerResponseDto?>
    UpdateAsync(
        int id,
        UpdateCustomerDto dto)
    {
        try
        {
            CustomerValidator.Validate(dto);

            using var con =
                _connectionFactory.CreateConnection();
            await con.OpenAsync(); // Open connection early to run the uniqueness check

            // 1. INLINE ADO.NET UNIQUE EMAIL CHECK (Excluding Current Record ID)
            string checkSql = "SELECT COUNT(1) FROM Customers_Krish WHERE LOWER(Email) = LOWER(@Email) AND Id <> @Id AND IsDeleted = 0";
            using (var checkCmd = new SqlCommand(checkSql, con))
            {
                checkCmd.Parameters.AddWithValue("@Email", dto.Email);
                checkCmd.Parameters.AddWithValue("@Id", id);
                int count = Convert.ToInt32(await checkCmd.ExecuteScalarAsync());
                
                if (count > 0)
                {
                    throw new ValidationException(new List<string> { "This email address is already registered to another customer." });
                }
            }
            using var cmd =
                new SqlCommand(
                    "sp_Customers_Update_Krish",
                    con);

            cmd.CommandType =
                CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue(
                "@Id",
                id);

            cmd.Parameters.AddWithValue(
                "@FirstName",
                dto.FirstName);

            cmd.Parameters.AddWithValue(
                "@LastName",
                dto.LastName);

            cmd.Parameters.AddWithValue(
                "@Email",
                dto.Email);

            cmd.Parameters.AddWithValue(
                "@DateOfBirth",
                dto.DateOfBirth);

            cmd.Parameters.AddWithValue(
                "@City",
                dto.City);

            // await con.OpenAsync();

            var rows =
                await cmd.ExecuteNonQueryAsync();

            if (rows == 0)
            {
                throw new NotFoundException(
                    "Customer not found");
            }

            return await GetByIdAsync(id);
        }
        catch (SqlException ex)
        {
            throw new Exception(
                "Failed to update customer.",
                ex);
        }
    }

    public async Task<bool>
DeleteAsync(int id)
    {
        try
        {
            using var con =
                _connectionFactory.CreateConnection();

            using var cmd =
                new SqlCommand(
                    "sp_Customers_Delete_Krish",
                    con);

            cmd.CommandType =
                CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue(
                "@Id",
                id);

            await con.OpenAsync();

            var rows =
                await cmd.ExecuteNonQueryAsync();

            if (rows == 0)
            {
                throw new NotFoundException(
                    "Customer not found");
            }

            return true;
        }
        catch (SqlException ex)
        {
            throw new Exception(
                "Failed to delete customer.",
                ex);
        }
    }

    
}