using Backend.Data;
using Backend.Interfaces;
using Backend.Middlewares;
using Backend.Repositories;
using Backend.Repositories.ADO;
using Backend.Repositories.EFCore;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AngularAppPolicy", policy =>
    {
        policy.WithOrigins("http://localhost:4200") // Allows your Angular app
              .AllowAnyMethod()                     // Allows GET, POST, PUT, DELETE
              .AllowAnyHeader();                    // Allows your custom X-Database-Type header
    });
});
builder.Services.AddDbContext<ApplicationDbContext>(
    options =>
    {
        options.UseSqlServer(
            builder.Configuration
            .GetConnectionString(
                "DefaultConnection"));
    });
    builder.Services.AddScoped<DbConnectionFactory>();
builder.Services.AddScoped<CustomerAdoRepository>();
builder.Services.AddScoped<CustomerEfRepository>();
builder.Services.AddScoped<IRepositoryResolver, RepositoryResolver>();
builder.Services.AddControllers(); 
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
        options.RoutePrefix = string.Empty; 
    });
}
app.UseMiddleware<GlobalExceptionMiddleware>();
app.UseHttpsRedirection();
app.UseCors("AngularAppPolicy"); 
app.UseAuthorization();

app.MapControllers(); 

app.Run();
