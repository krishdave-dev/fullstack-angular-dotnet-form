using Microsoft.Data.SqlClient;

namespace Backend.Data;
//using this we dont need to change every file when database is changed we just change this file
public class DbConnectionFactory
{
    private readonly IConfiguration _configuration;

    public DbConnectionFactory(IConfiguration configuration)//iconfig reads the appsettings.json securely
    {
        _configuration = configuration;
    }

    public SqlConnection CreateConnection()
    {
        return new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
    }
}