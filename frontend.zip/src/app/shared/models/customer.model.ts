export interface Customer{
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    dateOfBirth: string //yyyy-mm-dd
    city: string;
    isDeleted: boolean;
    createdAt: string;
    updatedAt?: string | null;
    deletedAt?: string | null;
}

export interface CreateCustomerDto{
    firstName: string;
    lastName: string;
    email: string;
    dateOfBirth: string //yyyy-mm-dd
    city: string;
}

export interface UpdateCustomerDto{
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    dateOfBirth: string //yyyy-mm-dd
    city: string;
}

export interface CustomerQueryDto{
    pageNumber: number;
    pageSize: number;
    search?: string | null;
    searchBy?: string | null;
    sortBy?: string | null;
    sortDescending: boolean;
}

export interface PagedResponse<T>{
    data: T[];
    pageNumber: number;
    pageSize: number;
    totalRecords: number;
    totalPages: number;
    hasPreviousPage: boolean;
    hasNextPage: boolean;
}
export interface CustomerResponseDto {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: string; // ISO string format (YYYY-MM-DD)
  city: string;
}

export interface ApiResponse<T>{
    statusCode: number;
    success: boolean;
    message: string;
    data: T;
    errors?: string[] | null;
}